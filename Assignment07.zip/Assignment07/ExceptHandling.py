#-------------------------------------------------#
# Title: Working with Except Handling and Pickles
# Dev:   Sarah Rickli
# Date:  Feb 23, 2019
# ChangeLog: (Who, When, What)

#-- Data --#
# declare variables and constants
# filename = a file been handled
# objFile = An object that represents a file
# word = text data from the file
# dictList = A row of data separated into elements of a dictionary {word, count}
# x = Capture the user answer

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the data you have
# in a text file into a python Dictionary.

# Step 2
# The dictionary created is stored with pickle.

# Step 3
# The user can ask to see the frequency of a word.

# Step 4
# Exit program
#-------------------------------1
import pickle

filename = "alice.txt"
dictList = {}
ObjFile = ""
word = ""
x = ""

try:
    # opens the file
    ObjFile = open(filename, "r")

# handle specific or general raised errors
except FileNotFoundError:
    print("This file does not exist.")
    exit()
except NameError:
    print("I do not have a file to open.")
    exit()
except Exception as e:
    print("There was a unexpected error!")
    print("pythons error info: ")
    print(e)
    exit()

# creates a dictionary of words in the file {word: count of word}
for word in ObjFile.read().lower().split():
    # takes some punctuations out of the text
    word = word.strip(',.;!--`:')
    if word not in dictList:
        dictList[word] = 1
    else:
        dictList[word] += 1

# print(dictList)

# pickles the dictionary created
# it's possible to create a word inventory of different texts/books
pDictList = open("wordsInventory.dat", "ab")

pickle.dump(dictList, pDictList)

pDictList.close()

# while the user asks for a word, its frequency in the text is given
# the loop will stop when the user asks to leave the program
while True:

    try:
        x = input("There are a few words in this text! "
                  "Which word are you curious to know how many times it appears? " + "\n"
                  "If you are not interested, type 'exit'.")
        print() # adds a new line
        # display a goodbye message e ends the program
        if (x.lower()) == "exit":
            print("I hope I see you again!")
            break
        # shows how many times a word appears in the text
        else:
            print(str(x) + " appears " + str(dictList[x.lower()]) + " times.")
            print() #adds a new line

    # handle the possible errors that may occur.
    except KeyError as y:
        print("Sorry! The word " + str(y) + " does not exist in this text. Try another one!")
    except Exception as z:
        print("whoopsss! Something went wrong: " + str(z) + "Try again!")

ObjFile.close() # closes the file
