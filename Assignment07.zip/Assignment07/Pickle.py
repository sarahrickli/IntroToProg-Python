#-------------------------------------------------#
# Title: Working with Except Handling and Pickles
# Dev:   Sarah Rickli
# Date:  Feb 23, 2019
# ChangeLog: (Who, When, What)

#-- Data --#
# declare variables and constants
# filename = a file been handled
# objFile = An object that represents a file
# word = text data from the file
# dictList = A row of data separated into elements of a dictionary {word, count}
# pDictList = An object that represents the pickled data
# upDictList =  An object that represents the un-pickled data

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the data you have
# in a text file into a python Dictionary.

# Step 2
# The dictionary created is dumped to a object file.

# Step 3
# Data is un-pickled.

# Step 4
# Un-pickled data is printed to confirm it worked.
#-------------------------------1

import pickle

filename = "alice.txt"
dictList = {}
word = ""
pDictList = ""
upDictList = ""

try:
    # opens the file
    ObjFile = open(filename, "r")


# handle specific or general raised errors
except FileNotFoundError:
    print("This file does not exist.")
    exit()
except NameError:
    print("I do not have a file to open.")
    exit()
except Exception as e:
    print("There was a unexpected error!")
    print("pythons error info: ")
    print(e)
    exit()

# creates a dictionary of words in the file {word: count of word}
for word in ObjFile.read().lower().split():
    # takes some punctuations out of the text
    word = word.strip(',.;!--`:')
    if word not in dictList:
        dictList[word] = 1
    else:
        dictList[word] += 1

try: # error handling for pickling process
    # print(dictList)
    # pickles the dictionary created
    pDictList = open("wordsInventory.dat", "wb")

    pickle.dump(dictList, pDictList)

    pDictList.close()

except Exception as z:
    print("Something went wrong: " + str(z))
    exit() # exits the program if an error is raised
# ____________________________________________

try: # error handling for un-pickling process

    # un-pickles the data
    upDictList = open("wordsInventory.dat", "rb")
    dictList2 = pickle.load(upDictList)
    upDictList.close()

except Exception as err:
    print("Something went wrong: " + str(err))
    exit() # exits the program if an error is raised

# prints the un-pickled data

for k,v in dictList2.items():
    print(k, v)

